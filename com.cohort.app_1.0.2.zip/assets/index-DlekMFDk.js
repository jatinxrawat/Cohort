import{r as i}from"./index-DfhH9xmR.js";import"./ui-BpWrZKTC.js";import"./vendor-CRq7X-j1.js";import"./firebase-COWBmtBD.js";const m=i("PushNotifications",{});export{m as PushNotifications};
