import{r as i}from"./index-DT9qTi4p.js";import"./ui-CvjrYCuN.js";import"./vendor-CRq7X-j1.js";import"./firebase-COWBmtBD.js";const m=i("PushNotifications",{});export{m as PushNotifications};
